import React from "react";
import Lady from "../Images/lady.png";


const Product = () => {

  return (
    <div className="product">
      <div className="img">
        <img src={Lady} alt="" />
        <span className="arrow">
          <i class="fa-solid fa-arrow-up"></i>
        </span>
      </div>
      <div className="product-text">
        <p className="product-text-title">FLORIDA JACKET</p>
        <p className="product-text-desc">
          Suffered alteration in some form, bysuffalteration in some forme,
          byinjected humor, or randomised
        </p>
        <p className="product-text-price">$100</p>
      </div>
    </div>
  );
};

export default Product;
