import React, { useRef } from "react";
import Product from "./Product";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

const NewProducts = () => {
  const sliderRef = useRef(null);
  const goToPrevSlide = () => {
    sliderRef.current.slickPrev();
  };

  const goToNextSlide = () => {
    sliderRef.current.slickNext();
  };
  const settings = {
    dots: true,
    infinite: false,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: false,
    autoplaySpeed: 2000,
  };
  return (
    <div className="new-products">
      <div className="slider-controls">
        <span onClick={goToNextSlide} className="next-btn">&#8594;</span>
        <span onClick={goToPrevSlide} className="prev-btn">&#8592;</span>
      </div>
      <span className="title">New products</span>
      <div className="inner">
        <div className="side-bar">
          <li>Apparel</li>
          <li className="selected">Accessories</li>
          <li>Best Sellers</li>
          <li>50% off</li>
        </div>
        <div className="products">
          <Slider {...settings} ref={sliderRef}>
            <Product />
            <Product />
            <Product />
            <Product />
          </Slider>
        </div>
      </div>
    </div>
  );
};

export default NewProducts;
